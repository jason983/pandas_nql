# Pandas NQL (Natural Language Query)
The Natural Language Query (NQL) library allows for querying Pandas Dataframe data using natural language queries.

### WARNING: PyPi is not accepting new registraions at this time so I couldn't upload the package therefore pip install won't work.

### Installation
```
pip install pandas_nql
```

### Prerequisites
OPENAI_API_KEY Environment variable must be set with a valid OpenAI Api Key
Python3.9+

### Get started
How to select data from a Pandas dataframe using natural language:

```Python
import pandas as pd
from pands_nql import PandasNQL

# load Dataframe
data = {
    'Name': ['John', 'Jane', 'Bob', 'Jason', 'Mike'],
    'Age': [25, 30, 22, 47, 46],
    'City': ['New York', 'San Francisco', 'Seattle', 'Denver', 'Denver']
}

df = pd.DataFrame(data)

# Instantiate PandasNQL object passing in data to query
pandas_nql = PandasNQL(df)

# Call the query method to select data
results_df = pandas_nql.query("select the average age of people in Denver.")

print(results_df)

# ...

```

### Generators
Allows for custom sql statement generators. The default uses OpenAI.

#### Write custom generator

```Python
from generators import SqlStatementGeneratorBase

# define custom sql stement generator class
class CustomSqlGenerator(SqlGeneratorBase):
    
    def __init__(self, ...):
        super().__init__()        

    # override generate_sql method
    def generate_sql(self, query: str, schema: str, dataset_name: str = TEMP_VIEW_NAME) -> str:
        # generate sql statement
        # return sql statement
```

#### Use custom generator

```Python
import pandas as pd
from pands_nql import PandasNQL

# load Dataframe
df = ...

# instatiate custom generator
custom_generator = CustomSqlGenerator(...)

# Instantiate PandasNQL with data
pandas_nql = PandasNQL(df, generator=custom_generator)

# Call the query method to select data
results_df = pandas_nql.query("select the average age of people in Denver.")

print(results_df)
```